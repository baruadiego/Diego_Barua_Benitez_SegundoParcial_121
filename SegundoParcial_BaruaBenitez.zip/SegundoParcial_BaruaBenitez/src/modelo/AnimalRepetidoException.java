package modelo;

public class AnimalRepetidoException extends RuntimeException{
    private final static String MESSAGE = "El animal con ese numero de ID ya se encuentra registrado";

    public AnimalRepetidoException() {
        super(MESSAGE);
    }
}
