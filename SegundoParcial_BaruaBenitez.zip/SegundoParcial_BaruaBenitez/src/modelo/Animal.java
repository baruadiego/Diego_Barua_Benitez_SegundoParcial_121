package modelo;

import java.io.Serializable;
import java.util.Objects;

public class Animal implements Comparable<Animal>, CSVSerializable{
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        if (id < 0){
            throw new IllegalArgumentException("El ID no puede ser menor a 0");
        }
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }
    
    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }
    
    @Override
    public int compareTo(Animal otro) {
        return Integer.compare(id, otro.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion.name();
    }
    
    public static Animal fromCSV(String lineaCSV){
        String[] data = lineaCSV.split(",");
        
        if (data.length == 4) {
            try {
                int id = Integer.parseInt(data[0]);
                String nombre = data[1];
                String especie = data[2];
                TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(data[3]);
                
                return new Animal(id, nombre, especie, alimentacion);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
        
        return null;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Animal otro = (Animal) obj;
        return this.id == otro.id;
    }
    
    
}
