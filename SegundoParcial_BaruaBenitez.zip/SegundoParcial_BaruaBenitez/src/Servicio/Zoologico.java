package Servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.CSVSerializable;
import modelo.AnimalRepetidoException;

public class Zoologico <T extends CSVSerializable> implements Iterable<T> {
    private List<T> items = new ArrayList<>();

    public void agregar(T elemento) {
        if (elemento == null) {
            throw new NullPointerException();
        }
        if (items.contains(elemento)) {
            throw new AnimalRepetidoException();
        }
        items.add(elemento);
    }

    public T obtener(int indice) {
        validateIndex(indice);
        return items.get(indice);
    }

    public void eliminar(int indice) {
        validateIndex(indice);
        items.remove(indice);
    }

    public int tamanio() {
        return items.size();
    }
    
    private void validateIndex(int indice){
        if (indice < 0 || indice >= tamanio()) {
            throw new IllegalArgumentException("El item no existe en la lista");
        }
    }
    
    public void ordenar(){
        ordenar(null);
    }
    
    public void ordenar(Comparator<? super T> comparador){
        items.sort(comparador);
    }
    
    public void mostrarContenido (){
        for (T item : items) {
            System.out.println(item);
        };
    }
    
    public List<T> filtrar (Predicate <? super T> criterio){
        List<T> aux = new ArrayList<>();
        for (T t : items) {
            if (criterio.test(t)) {
                aux.add(t);
            }
        }
        
        return aux;
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        items.forEach(t -> accion.accept(t));
    }
    
    private static File crearArchivoCSV(String path){
        File file = new File(path);
        
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        
        return file;
    }
    
    public void guardarEnCSV (String path){
        File file = crearArchivoCSV(path);
        
        try(BufferedWriter bf = new BufferedWriter(new FileWriter(file))) {
            for (T t : items) {
                bf.write(t.toCSV()+ "\n");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void cargarDesdeCSV(String path, Function<String, T> fromCSV){
        items = new ArrayList<>();
        
        try (BufferedReader bf = new BufferedReader(new FileReader(path))){
            String linea;
            
            while ((linea = bf.readLine()) != null) {                
                if(linea.endsWith("\n")){
                    linea = linea.substring(linea.length()-1);
                }
                
                T t = fromCSV.apply(linea);
                if (t != null){
                    items.add(t);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void serializar (String path){
        if (!items.isEmpty() && items.getFirst() instanceof Serializable){
            try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))){
                output.writeObject(items);
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    }
    
    public void deserializar (String path){
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>)input.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Iterator<T> iterator() {
        return items.iterator();
    }

    @Override
    public void forEach(Consumer<? super T> action) {
        Iterable.super.forEach(action);
    }
}
